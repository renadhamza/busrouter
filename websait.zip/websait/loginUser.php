<?php 

session_start();
if(isset($_POST['name']) and isset($_POST['password']) ){
	$name = $_POST['name'];
	$password = $_POST['password'];
	if($name==null or $password==null){
		echo "<script>alert('Empty Fields');</script>";
			echo "<script>window.location.href='index.php';</script>";
	
	}
	require 'api/connect.php';
		try{
		
			$stmt = $db->prepare("SELECT * FROM office WHERE name=:name LIMIT 1");
          $stmt->execute(array(':name'=>$name));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
             if( $userRow['password'] == $password)
             {
				      $_SESSION['police'] =1;
                	echo "<script>alert('Login Success');</script>";
			echo "<script>window.location.href='police/';</script>";
	
             }
             else
             {
               throw new Exception("password is wrong");
             }
          }
          else {
               throw new Exception("User Not Found");
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";

  // echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
		}

}
else if(isset($_POST['id']) and isset($_POST['password'])){
  $id = $_POST['id'];
	$password = $_POST['password'];
	if($id==null or $password==null){
		echo "<script>alert('Empty Fields');</script>";
			echo "<script>window.location.href='index.php';</script>";
	
	}
	require 'api/connect.php';
		try{
		
			$stmt = $db->prepare("SELECT * FROM campaign_leader WHERE national_id=:id LIMIT 1");
          $stmt->execute(array(':id'=>$id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
             if( $userRow['password'] == $password)
             {
				      $_SESSION['leader'] =1;
	echo "<script>alert('Login Success');</script>";
			echo "<script>window.location.href='leader/';</script>";
	
             }
             else
             {
               throw new Exception("password is wrong");
             }
          }
          else {
         
          	throw new Exception("User not Found");
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";

  // echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
		}
}
else
{
	header("location:index.php");
}
	


?>