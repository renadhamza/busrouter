<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}

if(isset($_GET['id'])){
	$id  = $_GET['id'];
	require_once '../api/connect.php';
		try{
			
			$stmt = $db->prepare("delete from bus WHERE driver_id=:id");

			$stmt->execute(array(':id'=>$id));
         
          if($stmt->rowCount() > 0)
          {
              	$stmt = $db->prepare("delete from driver WHERE id=:id");

			$stmt->execute(array(':id'=>$id));
          if($stmt->rowCount() > 0)
                {
                   echo "<script>alert('Bus Deleted');</script>";
			echo "<script>window.location.href='requests.php';</script>";
             
                }   else{
                    	echo "<script>alert('There is an error ');</script>";
			echo "<script>window.location.href='requests.php';</script>";
                }      
         
              
          }
          else {
          	echo "<script>alert('There is an error ');</script>";
			echo "<script>window.location.href='requests.php';</script>";
          	
          }
		}
		catch(Exception $e){
  echo "<script>alert('There is an error ');</script>";
			echo "<script>window.location.href='requests.php';</script>";
		}	
}
else{
	header("location:requests.php");
}

?>