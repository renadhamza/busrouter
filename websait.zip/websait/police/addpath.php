<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}

 $path_id= $_POST['path_name'];
 $po = $_POST['buses'];
 require '../api/connect.php';
 
 try{
 		
          	// $path_id = $db->lastInsertId();
             // if( $userRow['password'] == $password)
          	// $result['lastid']=$path_id;

          	 $result['valid']=true;

          	
          	for($i=0;$i<sizeof($po);$i++){
          		$bus_id = $po[$i];
          		// testing if bus id exists reroute it.
				  {
					$stmt = $db->prepare("INSERT INTO road_portion (path_id, bus_id,reroute_date)VALUES(:path_id, :bus_id,CURRENT_TIMESTAMP)");
						$stmt->execute(array(':bus_id'=>$bus_id,':path_id'=>$path_id));
						if($stmt->rowCount()<0){
							$result['valid']=false;
						}

				  }
        
          		
          	}
          	if($result['valid']==false){
          	$result['msg'] ="try Again";

          	}
          	else{
          		$result['valid']=true;
          	$result['msg'] ="Added route successfully";
          	}
          	// json_encode("success");

     }catch(Exeption $e){
 	$result['valid'] = false;
 }
 	echo json_encode($result);
function checkIfBusExists($bus_id){
	require '../api/connect.php';
	try{
  	$stmt = $db->prepare("SELECT * FROM road_portion where bus_id=:bus_id LIMIT 1");
          $stmt->execute(array(':bus_id'=>$bus_id));
          if($stmt->rowCount()>0){
			return 1;
          }
		  else{
			  throw new Exception("error");
		  }
	}
	catch(Exception $e){
		return -1;
	}
}

?>