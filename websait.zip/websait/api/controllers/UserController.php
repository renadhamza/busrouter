<?php 

foreach (glob("model/*.php") as $filename)
{
    require $filename;
}
/**
* 
*/
Class UserController
{
 public function handleLogin(){
    if(!isset($_POST['national_id'])){
     throw new Exception("please pass national id with post");
    }
    if(!isset($_POST['password'])){
     throw new Exception("please pass password with post");
    }
    if(!isset($_POST['bus_number'])){
     throw new Exception("please pass bus_number with post"); 
    }
    return true;
    // for bus login
  }
  public function handleLeaderLogin(){
    if(!isset($_POST['national_id'])){
     throw new Exception("please pass national id with post");
    }
    if(!isset($_POST['password'])){
     throw new Exception("please pass password with post");
    }
 
    return true;
    // for Leader login
  }
  public function validatelogin($id,$bus_id, $password){
  

    try
       {
        if($id==null){
               throw new Exception("natonal_id is null");

        }
        if(!is_numeric($id)){
               throw new Exception("natonal_id must be integer numbers");

        }
        if($password ==null){
               throw new Exception("password is null");

        }
        if($bus_id ==null){
               throw new Exception("Bus ID is null");

        }
        if(!is_numeric($bus_id)){
               throw new Exception("bus_id must be integer numbers");

        }
        $user = new User();

        $user->login($id,$bus_id, $password);
          
       }
       catch(PDOException $e)
       {
           echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
       }
        
        }// end validate_login function.
  public function validateLeaderlogin($id, $password){
  

    try
       {
        if($id==null){
               throw new Exception("natonal_id is null");

        }
        if(!is_numeric($id)){
               throw new Exception("natonal_id must be integer numbers");

        }
        if($password ==null){
               throw new Exception("password is null");

        }
       
        $user = new User();

        $user->loginLeader($id, $password);
          
       }
       catch(PDOException $e)
       {
           echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
       }
        
        }// end validate_login function.

        public function getUsersCurrentLocations(){
          $user  = new User();
          $user->getAllBusesCurrentLocations();
    
        
        } // end getUsersCurrentLocations.
        public function UpdateUsersCurrentLocation($id, $lat, $lng,$token){
          if(!isset($id)){
               throw new Exception("please pass bus_id with post");
          }
          if(!isset($lat)){
               throw new Exception("please pass bus lat with post");
          }
          if(!isset($lng)){
               throw new Exception("please pass bus lng with post");
          }
          if($id==null){
               throw new Exception("bus_id is null");

          }
          if($lat==null){
               throw new Exception("bus_id is null");

          }
          if($lng==null){
               throw new Exception("bus_id is null");

          }
          $user  = new User();
          $user->updateUserLocation($id, $lat, $lng,$token);
    
        
        }

        public function handleUpdateUsersCurrentLocation(){
          if(!isset($_POST['national_id'])){
               throw new Exception("please pass national_id with post");
          }
          if(!isset($_POST['lat'])){
               throw new Exception("please pass bus lat with post");
          }
          if(!isset($_POST['lng'])){
               throw new Exception("please pass bus lng with post");
          }
          if(!isset($_POST['login_token'])){
               throw new Exception("please pass login token with post");
          }

          return true;
        
        }
        // handling handle National Id.
        public function handleNationalId(){
          if(!isset($_POST['national_id'])){
               throw new Exception("please pass national_id with post");
          }
          if(!isset($_POST['login_token'])){
               throw new Exception("please pass login_token with post");
          }
          return true;
        
        }
        // handling handle reset password.
        public function handleResetPassword(){
          if(!isset($_POST['national_id'])){
               throw new Exception("please pass national_id with post");
          }
          if(!isset($_POST['old_password'])){
               throw new Exception("please pass old_password with post");
          }
          if(!isset($_POST['new_password'])){
               throw new Exception("please pass new_password with post");
          }
          if(!isset($_POST['login_token'])){
               throw new Exception("please pass login_token with post");
          }
          return true;
        
        }
           // handling service code.
        public function handleGetAllPaths(){
          
          
          $user = new User();
          $user->handleGetAllPaths();
        
        }
        
          // Validation  National Id.
        public function validateNationalId($id,$login_token){
          if($id ==null){
               throw new Exception("please pass national_id");
          }
          else if(!is_numeric($id)){
               throw new Exception("please pass integer national_id");
          }
          else{
          $user = new User();
          $user->getBusesToLeader($id,$login_token);
            
          }
          } 
         // Validation  National Id.
        public function validateNationalIdBUS($id,$token){

          if($id ==null){
               throw new Exception("please pass national_id");
          }
          else if(!is_numeric($id)){
               throw new Exception("please pass integer national_id");
          }
          else{
          $user = new User();
          $user->getPathToBus($id,$token);
            
          }
        }
        // Validation  validateResetPassword.
        public function validateResetPassword($id,$old_password,$new_password,$login_token){
          if($id ==null){
               throw new Exception("please pass national_id");
          }
          else if(!is_numeric($id)){
               throw new Exception("please pass integer national_id");
          }
          else if($old_password==null){
               throw new Exception("please pass old password");
          }
          else if($new_password==null){
               throw new Exception("please pass New password");
          }
          else if($login_token==null){
               throw new Exception("please pass Login Token");
          }
          else if($old_password==$new_password){
               throw new Exception("Two passwords are the same");
          }
          else{
          $user = new User();
          $user->ResetPassword($id,$old_password,$new_password,$login_token);
            
          }
        }
  


}


?>