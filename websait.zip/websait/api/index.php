<?php 
foreach (glob("route/*.php") as $filename)
{
    require $filename;
}


?>