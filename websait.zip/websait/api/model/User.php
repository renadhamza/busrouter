<?php 
/**
* 
*/
Class User
{
  private $db;
  public function login($id,$bus_id ,$password)
  {
    require 'connect.php';
    // $notfound =0;
    // $passwordError =0;
    try{
      $stmt = $db->prepare("SELECT * FROM driver,bus WHERE driver.national_id=:id and bus.driver_id=driver.id LIMIT 1");
          $stmt->execute(array(':id'=>$id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
             if( $userRow['password'] == $password and $userRow['bus_number']==$bus_id)
             {
                $token = md5(date("y-m-d H:i:s"));
               $stmt = $db->prepare("UPDATE driver SET login_token=:token WHERE national_id=:id");

                $stmt->execute(array(':id'=>$id,':token'=>$token));
                   
                    if($stmt->rowCount() > 0){
                      $userRow['login_token']=$token;
                      $userRow['user_type']=0;
                      $userRow['bus_number']= $this->getBusNumber($id);
                   echo json_encode(array("status"=>"200","login_token"=>$token, "message"=>"login success", "data"=>$userRow));
                    return true;
                    }
                    else{
               throw new Exception("There is an error with login Token login Again");
                    }
             }
             else
             {
              // $passwordError++;
               throw new Exception("Invalid Data");
              
             }
          }
          else {
            // $notfound++;
               throw new Exception("Please check Your data and try again");            
          }
           // end login proccess.
       
    } // end try.
    catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    } // end catch.
  }// end login function.
  
  // leader login.
public function loginLeader($id, $password){
  require 'connect.php';
  try{
      $stmt = $db->prepare("SELECT * FROM campaign_leader WHERE national_id=:id LIMIT 1");
          $stmt->execute(array(':id'=>$id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
             if( $userRow['password'] == $password)
             {
                $token = md5(date("y-m-d H:i:s"));
               $stmt = $db->prepare("UPDATE campaign_leader SET login_token=:token WHERE national_id=:id");

                $stmt->execute(array(':id'=>$id,':token'=>$token));
                   
                    if($stmt->rowCount() > 0){
                      $userRow['login_token']=$token;
                      $userRow['user_type']=1;
                     $userRow['bus_number']=-1;
                   echo json_encode(array("status"=>"200","login_token"=>$token, "message"=>"login success", "data"=>$userRow));
                    return true;
                    }
                    else{
               throw new Exception("There is an error with login Token login Again");
                    }
             }
             else
             {
              // $passwordError++;
               throw new Exception("Password Error");
              
             }
          }
          else {
            // $notfound++;
               throw new Exception("Please check Your data and try again");            
          }
  }
  catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;

  } //end catch.
} // end login leader function. 
 

  public function getAllBusesCurrentLocations(){
    require_once 'connect.php';
    try{
       $stmt = $db->prepare("SELECT bus.id, bus.leader_id, bus.driver_id, bus.bus_number, bus.current_latitude, bus.current_longitude, driver.name, driver.password, driver.language, driver.national_id,driver.status,driver.phone  FROM bus,driver WHERE bus.driver_id=driver.id and bus.current_latitude!='NULL' and bus.current_longitude!='NULL'");
      $stmt->execute();
          $userLocations=$stmt->fetchAll(PDO::FETCH_ASSOC);

          if($stmt->rowCount() > 0)
          {
            $data = [];
          foreach ($userLocations as $value) {
            $value['lat']=$value['current_latitude'];
            $value['lang']=$value['current_longitude'];
            $data[] = $value;                    
          }
                echo json_encode(array("status"=>"200", "message"=>"success", "data"=>$data));

          }
          else {
            throw new Exception("There is an Error or empty data");
            
          }
    }
    catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    }
  } // end second func.

    public function updateUserLocation($id, $lat,$lng,$token){
    require_once 'connect.php';
    try{
      // user_type=0 for driver and user_type=1 for leader.
     $user_type= 0; 
      $token =$this->generate_token($token,$user_type );
     if($token==false){
     return false;
            // throw new Exception("Falid to verify user");
     }

      $stmt= $db->prepare("UPDATE bus,driver SET bus.current_latitude=:lat , bus.current_longitude=:lng WHERE driver.national_id=:id and bus.driver_id=driver.id");
       
      $stmt->execute(array(':id'=>$id,':lat'=>$lat,':lng'=>$lng));
         
          if($stmt->rowCount() > 0)
          {
         
                echo json_encode(array("status"=>"200", "message"=>"update Current Location success", "login_token"=>$token,"data"=>$stmt->rowCount()));
       
          }
          else if($stmt->rowCount()==0){
           echo json_encode(array("status"=>"200", "login_token"=>$token,"message"=>" Not Moving", "data"=>$stmt->rowCount()));
          }
          else {
            throw new Exception("Please check it it a valid national id ".$id);
            
          }
    }catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    }
  }
public function getBusesToLeader($id,$login_token){
    require_once 'connect.php';
    try{
      $user_type =1;
       $token =$this->generate_token($login_token,$user_type);
     if($token==false){
     
      return false;
     }

      $stmt = $db->prepare("SELECT * FROM campaign_leader,bus,driver WHERE campaign_leader.national_id=:id and bus.leader_id=campaign_leader.id and bus.driver_id=driver.id and bus.current_latitude!='NULL' and bus.current_longitude!='NULL'");

      $stmt->execute(array(':id'=>$id));
          $userLocations=$stmt->fetchAll(PDO::FETCH_ASSOC);
         
          if($stmt->rowCount() > 0)
          {
           $data = [];
          foreach ($userLocations as $value) {
            $value['lat']=$value['current_latitude'];
            $value['lang']=$value['current_longitude'];
            
            $data[] = $value;
          }
                echo json_encode(array("status"=>"200","login_token"=>$token, "message"=>"success", "data"=>$data));
       
          }
          else {
            throw new Exception("Please check it it a valid leader id "); 
          }
    }
    catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    }
  }

  public function getPathToBus($id,$token){
    require_once 'connect.php';
    try{
      $user_type =0;
      
     
     $bus_number =$this->getBusNumber($id);
     if($bus_number==-1) {
            throw new Exception("Please check it it a valid National id ");  
          }
      $stmt = 
      $db->prepare("SELECT location.latitude,location.longitude FROM `path_points`,`location` where path_points.path_id = (SELECT road_portion.path_id FROM `road_portion`,bus WHERE bus.bus_number=:bus_number AND road_portion.bus_id=bus.id ORDER BY road_portion.reroute_date DESC LIMIT 1) AND location.id = path_points.location_id");

      $stmt->execute(array(':bus_number'=>$bus_number));
          $userLocations=$stmt->fetchAll(PDO::FETCH_ASSOC);
         
          if($stmt->rowCount() > 0)
          {
           $data = [];
          foreach ($userLocations as $value) {
            $value['lat']=$value['latitude'];
            $value['lang'] = $value['longitude'];
            $data[] = $value;
          }
                echo json_encode(array("status"=>"200", "message"=>"success", "data"=>$data));
       
          }
          else {
            throw new Exception("Please check it it a valid BUS id ");  
          }
    }
    catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage(),"login_token"=>$token) ) ;
    }
  }
  // 
  public function handleGetAllPaths(){
    require_once 'connect.php';
    try{

      $stmt = 
      $db->prepare("SELECT * FROM `path` where name!='' and  name!='NULL'");

      $stmt->execute();
          $paths=$stmt->fetchAll(PDO::FETCH_ASSOC);
         
          if($stmt->rowCount() > 0)
          {
           $data = [];
          foreach ($paths as $value) {
            // get buses count.
             $buses_count = $this->BusesOnPath($value['id']);
            $value['buses_count'] = $buses_count;
            $data[] = $value;
          }
                echo json_encode(array("status"=>"200", "message"=>"success", "data"=>$data));
       
          }
          else {
            throw new Exception("There is no data ");  
          }
    }
    catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    }
  }

  // Rest Password.
      public function ResetPassword($id,$old_password,$new_password,$login_token){
    require_once 'connect.php';
    try{
      $user_type = $this->getUserType($id);
      $token = $this->generate_token($login_token,$user_type );
      if($token==false){
        return false;
      }
      if($user_type==0){
      $stmt = $db->prepare("SELECT * FROM driver WHERE national_id=:id AND password=:password LIMIT 1");        
      }
      else if($user_type==1){
      $stmt = $db->prepare("SELECT * FROM campaign_leader WHERE national_id=:id AND password=:password LIMIT 1");
        
      }
          $stmt->execute(array(':id'=>$id,':password'=>$old_password));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() <= 0){
            
            throw new Exception("Invalid old Password ");
           
          }
          if($user_type==0){
      $stmt = $db->prepare("UPDATE driver SET password=:newPassword WHERE national_id=:id");

          }else if($user_type==1){
      $stmt = $db->prepare("UPDATE campaign_leader SET password=:newPassword WHERE national_id=:id");

          }

      $stmt->execute(array(':id'=>$id,':newPassword'=>$new_password));
         
          if($stmt->rowCount() > 0)
          {
         
                echo json_encode(array("status"=>"200","login_token"=>$token, "message"=>"Password Updated successfuly", "data"=>"data"));
       
          }
          else if($stmt->rowCount()==0){
           echo json_encode(array("status"=>"200", "message"=>" Not Updated", "data"=>$stmt->rowCount()));
          }
          else {
            throw new Exception("Please check it it a valid data ");
            
          }
    }catch(Exception $e){
  echo json_encode(array("status"=>"400", "message"=>$e->getMessage())) ;
    }
  }

public function generate_token($token,$user_type)
  {
    require 'connect.php';
    
    try{
      if($user_type==0){
      $stmt = $db->prepare("SELECT * FROM driver WHERE login_token=:token LIMIT 1");
      }
      else if($user_type==1){
      $stmt = $db->prepare("SELECT * FROM campaign_leader WHERE login_token=:token LIMIT 1");        
      }
          $stmt->execute(array(':token'=>$token));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
            $user_id = $userRow['id'];
           $new_token = md5(date("y-m-d H:i:s"))  ;

            // save new token
            if($user_type==0){
             $stmt = $db->prepare("UPDATE driver SET login_token=:token WHERE id=:user_id");
            }else if($user_type==1){
             $stmt = $db->prepare("UPDATE campaign_leader SET login_token=:token WHERE id=:user_id");
            }
          $stmt->execute(array(':token'=>$new_token,':user_id'=>$user_id));
          if($stmt->rowCount()>=0){
              return $new_token;
          }else{
            throw new Exception("Invalid update login token login First");

          }

          }
          else {
            throw new Exception("Invalid login token login again");
            
          }
    }
    catch(Exception $e){
  echo json_encode(array("status"=>"401", "message"=>$e->getMessage())) ;
  return false;
    }
  }
// end function generate token.
// begin of function get user type.
function getUserType($national_id){
    require 'connect.php';
 try{
      $stmt = $db->prepare("SELECT * FROM driver WHERE national_id=:national_id LIMIT 1");
          $stmt->execute(array(':national_id'=>$national_id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
            return 0;
          }
          else {
          $stmt = $db->prepare("SELECT * FROM campaign_leader WHERE national_id=:national_id LIMIT 1");
          $stmt->execute(array(':national_id'=>$national_id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
            return 1;
          }
          else return -1;
            
          }
    }
    catch(Exception $e){
  // echo json_encode(array("status"=>"401", "message"=>$e->getMessage())) ;
  return -1;
    }
}
//end of function get user type.
// function get bus number for driver.
function getBusNumber($id){
   require 'connect.php';
 try{
      $stmt = $db->prepare("SELECT bus.bus_number FROM bus,driver WHERE driver.national_id=:national_id and bus.driver_id=driver.id LIMIT 1");
          $stmt->execute(array(':national_id'=>$id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
            return $userRow['bus_number'];
          }
          else {
            throw new Exception("error");
    }
 }
    catch(Exception $e){
  // echo json_encode(array("status"=>"401", "message"=>$e->getMessage())) ;
  return -1;
    }
}
// end get bus number function.
// function get buses count for path.
 function BusesOnPath($id){
   require 'connect.php';
 try{
      $stmt = $db->prepare("SELECT count(bus_id) as buses_count FROM `road_portion` WHERE path_id=:path_id and reroute_date >= subdate(current_date, 1)");
          $stmt->execute(array(':path_id'=>$id));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
            return $userRow['buses_count'];
          }
          else {
            throw new Exception("error");
    }
 }
    catch(Exception $e){
  // echo json_encode(array("status"=>"401", "message"=>$e->getMessage())) ;
  return -1;
    }
}
// end function get buses count for path.

}


?>