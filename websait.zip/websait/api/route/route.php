<?php
// include 'controllers/UserController.php';
foreach (glob("controllers/*.php") as $filename)
{
    require $filename;
}
//trigger exception in a "try" block
try {
  $result = check_service_code();
  //If the exception is thrown, this text will not be shown
  if($result ==1)
  $service_code = $_POST['service_code'];
  else 
  $service_code = $_GET['service_code'];

  if($service_code == 1){
   $usercontroller =  new UserController();
    $result = $usercontroller->handleLogin();
    
$national_id = $_POST['national_id'];
$bus_id = $_POST['bus_number'];
$password = $_POST['password'];
    $usercontroller->validatelogin($national_id,$bus_id, $password);
  }
  //  service_code =2 to get locations of all buses to view them 
  // for police.
  else if($service_code ==2){

    $usercontroller =  new UserController();
      $usercontroller ->getUsersCurrentLocations();
  } 
  // $service_code = 3 for update current bus location
  else if($service_code ==3){
      // POST["bus_id","lat","lng"].
    $usercontroller =  new UserController();
    $usercontroller->handleUpdateUsersCurrentLocation();
      $usercontroller ->UpdateUsersCurrentLocation($_POST['national_id'], $_POST['lat'],$_POST['lng'],$_POST['login_token']);
  }
  else if($service_code ==4){
      
    $usercontroller =  new UserController();
    $usercontroller->handleNationalId();
      $usercontroller ->validateNationalId($_POST['national_id'],$_POST['login_token']);
  }
  else if($service_code ==5){
      
    $usercontroller =  new UserController();
    $usercontroller->handleNationalId();
      $usercontroller ->validateNationalIdBUS($_POST['national_id'],$_POST['login_token']);
  }
  // Reset Password.
  else if($service_code ==6){
      
    $usercontroller =  new UserController();
    $usercontroller->handleResetPassword();
      $usercontroller ->validateResetPassword($_POST['national_id'],$_POST['old_password'],$_POST['new_password'],$_POST['login_token']);
  }
   //Get All Paths , sevice code=7.
  else if($service_code ==7){
      
    $usercontroller =  new UserController();
    $usercontroller->handleGetAllPaths();
  }
  // Leader login
  else  if($service_code == 8){
  
    $usercontroller =  new UserController();
    $result = $usercontroller->handleLeaderLogin();
    
$national_id = $_POST['national_id'];
$password = $_POST['password'];
    $usercontroller->validateLeaderlogin($national_id, $password);
  }
  else{
    throw new Exception("please enter valid service_code");

  }

}

//catch exception
catch(Exception $e) {
  echo json_encode(array("status"=>"400","message"=> $e->getMessage()));
  
}

//create function with an exception
function check_service_code() {
  if(!isset($_POST['service_code']) and !isset($_GET['service_code'])) {
    throw new Exception("service_code must be sent with post|get method");
  }
  if(isset($_POST['service_code']))
  return 1;
  if(isset($_GET['service_code']))
  return 2;
}

?>