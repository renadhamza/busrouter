<?php 
 $DB_host = "localhost";
 $DB_user = "root";
 $DB_pass = "";
 $DB_name = "anarbust_db";
		try
		{
		     $db = new PDO("mysql:host={$DB_host};dbname={$DB_name};charset=utf8",
		     	$DB_user,$DB_pass);
		     	
		     $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e)
		{
		     echo $e->getMessage();
		}

?>
