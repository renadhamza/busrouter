<?php 
session_start();
if(!isset($_SESSION['leader'])){
  header("location:../");
}

if(isset($_POST['bus_number']) and isset($_POST['name']) 
	and isset($_POST['phone']) and isset($_POST['national_id']) ){
	$bus_number = $_POST['bus_number'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$national_id = $_POST['national_id'];
	if($bus_number==null or $name==null or $phone==null or $national_id==null){
		echo "<script>alert('هناك حقول فارغة');</script>";
			echo "<script>window.location.href='index.php';</script>";
	
	}
	if(checkNationalIdexists($national_id)== true ){
		echo "<script>alert('الرقم الوطني المدخل مستخدم لحساب أخر');</script>";
			echo "<script>window.location.href='index.php';</script>";
	}
	if(checkBusNumberexists($bus_number)== true ){
		echo "<script>alert('رقم الباص مسجيل لحساب أخر');</script>";
			echo "<script>window.location.href='index.php';</script>";
	}
	require "../../api/connect.php";
		try{
			
		$st=-1;
		$stmt = $db->prepare("INSERT INTO driver (name,phone,national_id,password,status,login_token)VALUES(:name,:phone,:national_id,:national_id,:st,'NULL')");
        $stmt->execute(array(':national_id'=>$national_id,':bus_number'=>$bus_number,':phone'=>$phone,':name'=>$name,':st'=>$st));
          if($stmt->rowCount() > 0)
          {
			  $driver_id= $db->lastInsertId();
			  // adding bus and it's driver.
				 $stmt = $db->prepare("INSERT INTO bus (bus_number,driver_id)VALUES(:bus_number,:driver_id)");
          		$stmt->execute(array(':driver_id'=>$driver_id,':bus_number'=>$bus_number));
				  if($stmt->rowCount() > 0){
					echo "<script>alert('تم إضافة الباص بنجاح و الأن بانتظار الشرطي للموافقة عليه');</script>";
					echo "<script>window.location.href='index.php';</script>";
				  }
				  else{
					echo "<script>alert('تم أضافة الباص و لكن حدث خطأ في اضافة الباص الخاص به');</script>";
					echo "<script>window.location.href='index.php';</script>";
				  }
				
          }
          else {
          	throw new Exception("هناك خطأ ما الرجاء المحاولة مجددا و شكرا");
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";
		}

}
else
{
	echo "<script>alert('الرجاء التحقق من البيانات المدخلة');</script>";
			echo "<script>window.location.href='index.php';</script>";
}

	function checkNationalIdexists($val){
	require '../../api/connect.php';
		try{
			$stmt = $db->prepare("SELECT * FROM driver WHERE national_id=:id LIMIT 1");
          $stmt->execute(array(':id'=>$val) );
          if($stmt->rowCount() > 0)
          {
          	return true;

          }
          else {
          	return false;
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";
		}
		return false;
}

function checkBusNumberexists($val){
	require '../../api/connect.php';
		try{
			$stmt = $db->prepare("SELECT * FROM bus WHERE bus_number=:id LIMIT 1");
          $stmt->execute(array(':id'=>$val) );
          if($stmt->rowCount() > 0)
          {
          	return true;

          }
          else {
          	return false;
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";
		}
		return false;
}

?>