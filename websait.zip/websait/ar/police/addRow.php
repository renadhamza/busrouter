<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}

 $path_name= utf8_decode($_POST['path_name']);
 $po = $_POST['points'];
 require '../../api/connect.php';
 
 try{
 		$stmt = $db->prepare("INSERT INTO `path` (`name`,`creation_date`)values(:patho,CURRENT_TIMESTAMP)");
          $stmt->execute(array(':patho'=>$path_name));
          
          if($stmt->rowCount() > 0)
          {
          	$path_id = $db->lastInsertId();
             // if( $userRow['password'] == $password)
          	$result['lastid']=$path_id;

          	 $result['valid']=true;

          	
          	for($i=0;$i<sizeof($po);$i++){
          		$lat = $po[$i][0];
          		$lang = $po[$i][1];
          	$stmt = $db->prepare("INSERT INTO `location`( `latitude`, `longitude`) VALUES (:lat,:lng)");
          $stmt->execute(array(':lat'=>$lat,':lng'=>$lang));
          if($stmt->rowCount()==0){
			$result['valid']=false;
          }
		  $location_id = $db->lastInsertId();
          $stmt = $db->prepare("INSERT INTO  `path_points`(`path_id`,`location_id`)VALUES(:path_id,:location_id)");
          $stmt->execute(array(':location_id'=>$location_id,':path_id'=>$path_id));
          if($stmt->rowCount()==0){
			$result['valid']=false;
          }		
          	}
          	if($result['valid']==false){
          	$result['msg'] ="الرجاء المحاولة لاحقا";

          	}
          	else{
          		$valid =true;
          	$result['msg'] ="تم الإضافة بنجاح";
          	}
          	// json_encode("success");
          }else
 		// echo json_encode("error");
    		$result['valid']=false;
 }catch(Exeption $e){
 	$result['valid'] = false;
 }
 	echo json_encode($result);

?>