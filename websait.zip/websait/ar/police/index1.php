<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}
?>
<!DOCTYPE html>
<html>
  <head>
<title>صفحة الشرطي</title>
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="../style/custom_style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style  >
  .activeClass{
    background-color:red !important;
  }
  </style>
  <script>
    
    var list= ["refresh","path1","path2","path3","path4"];
function setActiveLink(str){
  
  for(var i=0;i<list.length;i++){
    $( "#"+list[i] ).css( "background-color", "#00ab67" );
    $( "#"+list[i] ).css( "color", "white" );
   // var l = documnet.getElementById(list[i]);
   // l.style="background-color:#00ab67"  ;
   // alert(l);
  }
$( "#"+str ).css( "background-color", " #f7f7f7" );
$( "#"+str ).css( "color", "black" );
}
    </script>
  </head>
  <body>
  <div class="top" style="width: 100%;height: 100px;background-color: #f7f7f7;">
    <center col-md-10>
    <img src="../img/logo.png" alt="" width="100" height="100" style="float: right;" >      
    </center>



  </div> 
  <div class="col-md-12 row custom_top" >
    <div class="col-md-9 " >
    
    <div id="map" style="height: 340px;"></div>
    <center style="margin-top: 15px;">
      <div class="row"  id="path">
                
        </div>
    <div class='row'  id="BusesList"></div>
    </center>
  </div>
  <div class="col-md-3    text-center" >
        <br>
        <button class=" button" id="refresh" onclick="pathFuncReset();btnNotClicked();initMap();setActiveLink(this.id);"> تحديث 
        <i class="fa fa-refresh" ></i></button>
          <div class="panel">
            <!-- <p>Lorem ipsum...</p> -->
          </div>

          <button class=" button" id="path1" 
           onclick="btnClicked();initMap_create_path();setActiveLink(this.id);"> إنشاء طريق <i class="fa fa-bus"></i></button>
          <div class="panel2" >
            <center>
              <!-- <p style="max-width: 150px;" id="path">
                
              </p> -->
            </center>
          </div>

          <button class=" button" id="path2" onclick="btnClicked();pathFunc();initMap();open_path_link();setActiveLink(this.id);"> إعادة توجيه الباص 
        <i class="fa fa-bus"></i></button>
          <div class="panel3">
            <center>
             <!--  <p style="max-width: 220px;" id="BusesList"></p> -->
            </center>
          </div>
          <a class="button" href="requests.php" id="path3" onclick="setActiveLink(this.id);">طلبات التسجيل <i class="fa fa-bus"></i></a>
            <a class="button" href="leader.php" id="path4"> إضافة قائد حملة </a>
            <a class="button" href="../logout.php" > تسجيل الخروج </a>
  </div>
    </div>
      <!-- Control section -->
      <div class="control" id="control">
        
      </div>
    </div>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4JJjJ_aV4rcEmLVoIpoVEVA6lJO1zf1s&callback=initMap">
    </script>
  </body>
</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    
<script
  src="http://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>

    <script >

            /// vars
     var markers = [];
        var counter = 0;
        var infowindows = [];
        var busesForPath = [];
        var busesList = [];
        var busesIds = [];
          var clicked =0, toPathVar =0;

 setInterval(function () {
  if(clicked!=1)
           initMap();
        }, 5000);

  function initMap() {

    // rest path field if there is data.
    var temp_path = document.getElementById('path');
    temp_path.innerHTML = "";
          // markers =[];
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng( 
21.4359571,   
39.9866326),
          zoom:8
        });
        var infoWindow = new google.maps.InfoWindow;
           var text = new XMLHttpRequest();
          text.open("GET", "../../api/?service_code=2", true);
          text.onreadystatechange = function() {
        // Check states 4 = Ready to parse, 200 = found file
        if(text.readyState === 4 && text.status === 200) {
            var data = text.responseText;
            data_used = JSON.parse(data);
            // alert(data_used.data.length);
            var obj = data_used.data;

            for(var i=0;i<obj.length;i++){
          
            if(obj[i].lat!==null && obj[i].lang!==null){
              //alert(obj[i].lat);
              markers.push( new google.maps.LatLng(obj[i].lat, obj[i].lang));
               var contentString =
              '<pre id="' +markers.length+'"> ' +' الرقم الوطني :'+obj[i].national_id +'<br>'+
              'الاسم :'+obj[i].name +'<br>'
         contentString +='</pre> ';
        if(toPathVar ==1){
          var pos = markers.length-1;
          // alert(markers[pos].lat());
          var contentString =
              '<pre id="' +markers.length+'"> ' +'الرقم الوطني :'+obj[i].national_id +'<br>'+
              'الاسم :'+obj[i].name +'<br>'
         contentString +='<button id="' +markers.length+'" onclick="addBusForPath('+pos+','+ obj[i].id+','+obj[i].national_id +')">تحديد</button></pre> ';
        
        }

        var marker = new google.maps.Marker({
          position: markers[i],
          map: map,
          title: 'Uluru'
        });
        
           
      marker['infowindow'] = new google.maps.InfoWindow({
            content:contentString 
        });

    google.maps.event.addListener(marker, 'click', function() {
        this['infowindow'].open(map, this);
    });

            }  // alert(markers.length);
            } //end for loop.
        if(toPathVar ==1){
           var bounds = {
          north: 21.432205826483667,
            south: 21.32707407822287,
            east: 39.41752294921878,
            west: 39.298296875000005
        };
   
        // Define the rectangle and set its editable property to true.
        rectangle = new google.maps.Rectangle({
          bounds: bounds,
          editable: true,
          draggable: true
        });

        rectangle.setMap(map);

        // Add an event listener on the rectangle.
        rectangle.addListener('bounds_changed', showNewRect);

        // Define an info window on the map.
        infoWindow = new google.maps.InfoWindow();
      
      // Show the new coordinates for the rectangle in an info window.

      /** @this {google.maps.Rectangle} */
      function showNewRect(event) {
        var ne = rectangle.getBounds().getNorthEast();
        var sw = rectangle.getBounds().getSouthWest();

        var contentString = '<b>Rectangle moved.</b><br>' +
            'New north-east corner: ' + ne.lat() + ', ' + ne.lng() + '<br>' +
            'New south-west corner: ' + sw.lat() + ', ' + sw.lng();
        // alert(busesForPath.length);
            busesList=[];
            busesForPath =[];
        for(var i=0;i<markers.length;i++){
// alert(markers[i].lat());
            if(markers[i].lat()<=ne.lat() && markers[i].lat()>=sw.lat() && markers[i].lng()<=ne.lng() && markers[i].lng()>=sw.lng() ){
              // selected_markers.push(markers[i]);
            // alert("pos1 : "+ ne.lat() +" pos2 "+ sw.lat()+" pos3 "+ ne.lng() +" pos4 "+ sw.lng()); 
            // alert("b"+markers[i].lng());
            if(busesList.indexOf(markers[i].id)==-1){

            busesList.push(obj[i].id); 
            busesIds.push(obj[i].national_id);
            }
            if(busesForPath.indexOf(markers[i])==-1){
            busesForPath.push(markers[i]); 
              
            }
            // alert("s"+markers[i].lng());
            open_path_link();
  

            } // end if.
        // else alert("The point is out of rectangle");
            }// end for.
            // alert("current elements count "+ selected_markers.length);
        // Set the info window's content and position.
        infoWindow.setContent(contentString);
        infoWindow.setPosition(ne);

        infoWindow.open(map);
      }
        }

        } // end if function.

}
    text.send(null);
    // 
markers =[];
        } // end initMap.

     function btnClicked(){
      clicked =1;

     }
     function btnNotClicked(){
      clicked =0;
     }
 function pathFunc(){
      toPathVar =1;
                       $("#path").css("visibility","hidden");
            $("#BusesList").css("visibility","visible");
     } 
     function pathFuncReset(){
      toPathVar =0;
     } 

      function addBusForPath(data, id,national_id){
        // alert(data);
        if(busesForPath.indexOf(markers[data])){
          busesForPath.push(markers[data]);
          
        }
        if(busesList.indexOf(id)==-1){
          busesList.push(id);
        }
        if(busesIds.indexOf(national_id)==-1){
          busesIds.push(national_id);
        }

     open_path_link();
     }
   

        function initMap_create_path() {
         
        open_path_message();
            $("#path").css("visibility","visible");
            $("#BusesList").css("visibility","hidden");
         // reset.
          markers = [];
         counter = 0;
         infowindows = [];
            var uluru = {lat: -25.363, lng: 131.044};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: new google.maps.LatLng(21.4359571, 39.9866326)
        });


           map.addListener('click', function(event) {
          // addMarker(event.latLng);

                  var contentString =
         '<button id="' +markers.length+'" name="test" ';
         contentString +=' onclick="delete_marker(this.id);">Delete</button>';
          var infowindow = new google.maps.InfoWindow({
          content: contentString
        });
        // open_path_message();

        var marker = new google.maps.Marker({
          position: event.latLng,
          map: map,
          title: 'Uluru'
        });
        markers.push(marker);
        open_path_message();
        counter++; 
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
        });
      }
      
      function delete_marker( counter){
        // alert("Delete Fuction" + counter);
       markers[counter].setMap(null) ;
       markers[counter].position=null;
        // alert("new length" +markers.length);
        
        open_path_message();
        show_points();

      }
      function show_points(){
        for(var i =0; i<markers.length;i++){
                   var contentString =
         '<button id="' +i+'" name="test" ';
         contentString +=' onclick="delete_marker(this.id);">Delete</button>';
          var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

        var marker = new google.maps.Marker({
          position: markers[i],
          map: map,
          title: 'Uluru'
        });
        
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
       

        }

      } // end init map function.



function open_path_message(){
  // alert(latlng);
  var string = "<div class='col-md-3'>الرجاء اختيار النقاط لرسم الطريق</div>";
  string += "<div class='col-md-3'> اسم الطريق : <input id='path_name' type='text'></div>";
  // for(var i=0;i<markers.length;i++){
  //   if(markers[i].position==null)continue;
  //   string +=""+ markers[i].position;
  // }
  string += "<div class='col-md-2'><button id='saveData' onclick='saveData();'> إنشاء</button></div>";
   document.getElementById("path").innerHTML = string;
  
  
}

function open_path_link(){

    var pathsList = "";
      // begin of fetching paths.
      var text = new XMLHttpRequest();
          text.open("GET", "../../api/?service_code=7", true);
          text.onreadystatechange = function() {
        // Check states 4 = Ready to parse, 200 = found file
        if(text.readyState === 4 && text.status === 200) {
            var data = text.responseText;
            data_used = JSON.parse(data);
            // alert(data_used.data.length);
            var obj = data_used.data;

            for(var i=0;i<obj.length;i++){
              // alert(obj[i].name)
              pathsList += "<option value='"+obj[i].id+"' class='form-control'>"+obj[i].name+"</option>";
              var string = "";
              



            } //end for loop.
  string += "<div class='col-md-3'><select id='path_name' size='6' multiple='multiple' >"+pathsList+"</select></div> ";
  string += "<div class='col-md-3' style='height: 280px;overflow-y: auto;'><table class='table table-striped' style=' overflow-y: auto;'><tr><th>الرقم</th><th>حذف</th></tr>";
  for(var i=0;i<busesForPath.length;i++){
    if(busesForPath[i]!="-1" && busesIds[i]!=-1)
    string +="<tr style='height:22px;'><td>"+busesIds[i]+"</td><td><a onclick='Delete_bus_form_list("+i+","+busesIds[i]+");' style='cursor:pointer;'>حذف</a></td></tr>";
  }
  string += "</table></div><div class='col-md-2'><button id='savePath' class='btn' onclick='savePath();'>إعادة توجيه</button></div>";
   document.getElementById("BusesList").innerHTML = string;
  
              
        
        } // end if function.

}

    text.send(null);
      // end of fetching paths.
    
  
}

// delete bus while rerouting.
function Delete_bus_form_list(num, ids){
  busesForPath[num]="-1";
  
  for(var i=0;i<busesIds.length;i++){
    if(busesIds[i]==ids){
      busesIds[i] =-1;
    }
  }
  open_path_link();
}

        var points_to_save = [];
        var data;
        
  function saveData() {
        // alert(markers.length);\

        for(var i=0;i<markers.length;i++){
          if(markers[i].position!=null){
            // alert("pos:"+ markers[i].getPosition().lat() +" lng"+markers[i].getPosition().lng());
            points_to_save.push( new Array(markers[i].getPosition().lat(),markers[i].getPosition().lng()) ); 
          }
        }
         data = escape(document.getElementById('path_name').value);
        // var address = escape(document.getElementById('address').value);
        
        // var latlng = marker.getPosition();
        var url = 'addRow.php';
        //            '&lat=' + latlng.lat() + '&lng=' + latlng.lng();
          $.ajax({
            url:"addRow.php",
            type:'post',
            dataType:'json',
            data:{
              path_name:data,
              points:points_to_save
            }
          }).done(function(res){
            alert(res.msg);
            // alert(res.lastid);

          }).fail(function(err){
            alert(err +"error");
          });
        } // end function save data.


          function savePath() {
        // alert(markers.length);

         data = document.getElementById('path_name');
        data = data.options[data.selectedIndex].value;
      
        // var address = escape(document.getElementById('address').value);
        
        //            '&lat=' + latlng.lat() + '&lng=' + latlng.lng();
          $.ajax({
            url:"addpath.php",
            type:'post',
            dataType:'json',
            data:{
              path_name:data,
              buses:busesList
            }
          }).done(function(res){
            alert(res.msg);
            

          }).fail(function(err){
            alert(err +"error");
          });
        } // end save path function



    </script>