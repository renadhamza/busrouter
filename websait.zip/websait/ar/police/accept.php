<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}
if(isset($_GET['id'])){
	$id  = $_GET['id'];
	require_once '../../api/connect.php';
		try{
			$newStatus=1;
			$stmt = $db->prepare("UPDATE driver SET status=:newStatus WHERE id=:id");

			$stmt->execute(array(':id'=>$id,':newStatus'=> $newStatus));
         
          if($stmt->rowCount() > 0)
          {
         
               echo "<script>alert('تم قبول الباص بنجاح');</script>";
			echo "<script>window.location.href='requests.php';</script>";
       
          }
          else {
          	echo "<script>alert('حدث خطأ ما ');</script>";
			echo "<script>window.location.href='requests.php';</script>";
          	
          }
		}
		catch(Exception $e){
  echo "<script>alert('حدث خطأ ما ');</script>";
			echo "<script>window.location.href='requests.php';</script>";
		}	
}
else{
	header("location:requests.php");
}

?>