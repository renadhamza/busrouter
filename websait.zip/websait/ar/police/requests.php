<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> طلبات تسجيل الباصات</title>
<style>
	@import url(https://fonts.googleapis.com/css?family=Roboto:300);

.login-page {
  width: 100%;
  padding: 0% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  width: 70%;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #fcb042;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}

.form button:hover,.form button:active,.form button:focus {
  background: #d0d0d0;
  color: black;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #fcb042;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 50%;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
body {
  background: #f7f7f7; /* fallback for old browsers */
  background: -webkit-linear-gradient(right, #f7f7f7, #f7f7f7);
  background: -moz-linear-gradient(right, #f7f7f7, #f7f7f7);
  background: -o-linear-gradient(right, #f7f7f7, #f7f7f7);
  background: linear-gradient(to left, #f7f7f7, #f7f7f7);
  font-family: "Roboto", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;      
}
.btn{
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #00ab67;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
  text-decoration: none;

}
.btn-delete{
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #fc7742;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
  text-decoration: none;
}
table{
  width: 100%;
}
tr{
  height: 60px;
}
</style>
</head>
<body>

<div class="top" style="width: 100%;height: 150px;background-color: #f7f7f7;">
        <div class="col-md-6 "  >
          <img src="../img/logo.png" alt="" width="100" height="100" style="float: right;" >
        </div>
   <div class="col-md-6">
      <center>
      <div style="padding-top:50px; "><a href="index.php" >الرئيسية  </a> > <i class="fas fa-circle" style="color:red;"></i> <a href="requests.php">الطلبات</a> </div>
    </center>
   </div>
  </div>
    <div class="login-page">
  <div class="form">
     <table border="2">
      <tr>  
    <th> رقم الباص </th>
    <th> اسم المستخدم </th>
    <th> الرقم الوطني </th>
    <th>  رقم الهاتف </th>
    <th> قبول</th>
    <th> رفض</th>
      </tr>
      <?php 
        require_once '../../api/connect.php';
         try{
      $stmt = $db->prepare("SELECT driver.id, bus.bus_number, driver.name, driver.national_id, driver.phone FROM driver,bus WHERE bus.driver_id=driver.id and driver.status='-1'");
      $stmt->execute();
          $userLocations=$stmt->fetchAll(PDO::FETCH_ASSOC);

          if($stmt->rowCount() > 0)
          {
            
          foreach ($userLocations as $value) {
       echo 
           "<tr>".  
        "<td>".  $value['bus_number'] ."</td>".
        "<td>".$value['name']."</td>".
        "<td>" .$value['national_id']."</td>".
        "<td>".$value['phone']."</td>"
        ;
   ?>
   <td> <a href="accept.php?id=<?php echo $value['id']; ?>" class="btn">قبول</a></td>
        <td> <a href="delete.php?id=<?php echo $value['id']; ?>" class="btn-delete">حذف الطلب</a></td>';
<?php 
    echo  "</tr>";

          }
                
       
          }
          else {
            // throw new Exception("No users Found");
            
          }
    }
    catch(Exception $e){
        
    }
      ?>
       
    </table>
    <br><br>
<a href="index.php" class="btn" style="text-decoration: none;"> عودة</a>

  </div>
</div>
</body>
</html>
<script>
	$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
</script>