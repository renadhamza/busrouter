<?php 
session_start();
if(!isset($_SESSION['police'])){
  header("location:../");
}


if(isset($_POST['leader_name']) and isset($_POST['trip_id']) 
	 and isset($_POST['national_id']) ){
	$leader_name = $_POST['leader_name'];
	$trip_id = $_POST['trip_id'];
	
	$national_id = $_POST['national_id'];
	if($leader_name==null or $trip_id==null  or $national_id==null){
		echo "<script>alert('حقول فارغه');</script>";
			echo "<script>window.location.href='leader.php';</script>";
	
	}
	if(checkNationalIdexists($national_id)== true ){
		echo "<script>alert('الرقم الوطني مسجل من قبل لدينا');</script>";
			echo "<script>window.location.href='leader.php';</script>";
	}
	if(checkTripNumberexists($trip_id)== true ){
		echo "<script>alert('رقم رحلة الحج مسجل مسبقا');</script>";
			echo "<script>window.location.href='leader.php';</script>";
	}
	require '../../api/connect.php';
		try{
			
		
		$stmt = $db->prepare("INSERT INTO campaign_leader (name,national_id,password,hajj_permit,login_token)VALUES(:name,:national_id,:national_id,:trip_id,'NULL')");
        $stmt->execute(array(':national_id'=>$national_id,':name'=>$leader_name,':trip_id'=>$trip_id));
          if($stmt->rowCount() > 0)
          {

					echo "<script>alert('تم إضافة الرحلة بنجاح');</script>";
					echo "<script>window.location.href='leader.php';</script>";
				  
				
          }
          else {
          	throw new Exception("هناك خطأ الرجاء المحاولة مجددا");
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='index.php';</script>";
		}

}
else
{
	echo "<script>alert('الرجاء التحقق من جميع الحقول');</script>";
			echo "<script>window.location.href='index.php';</script>";
}

	function checkNationalIdexists($val){
	require '../../api/connect.php';
		try{
			$stmt = $db->prepare("SELECT * FROM campaign_leader WHERE national_id=:id LIMIT 1");
          $stmt->execute(array(':id'=>$val) );
          if($stmt->rowCount() > 0)
          {
          	return true;

          }
          else {
          	return false;
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='leader.php';</script>";
		}
		return false;
}

function checkTripNumberexists($val){
	require '../../api/connect.php';
		try{
			$stmt = $db->prepare("SELECT * FROM campaign_leader WHERE hajj_permit=:id LIMIT 1");
          $stmt->execute(array(':id'=>$val) );
          if($stmt->rowCount() > 0)
          {
          	return true;

          }
          else {
          	return false;
          	
          }
		}
		catch(Exception $e){

			echo "<script>alert('".$e->getMessage()."');</script>";
			echo "<script>window.location.href='leader.php';</script>";
		}
		return false;
}

?>