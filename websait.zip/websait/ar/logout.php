<?php 
session_start();
if(isset($_SESSION['leader'])){
	unset($_SESSION['leader']);
}
if(isset($_SESSION['police'])){
	unset($_SESSION['police']);
}
session_destroy();
                	echo "<script>alert('تم تسجيل الخروج بنجاح');</script>";
			echo "<script>window.location.href='index.php';</script>";
?>