    /// vars
     var markers = [];
        var counter = 0;
        var infowindows = [];

 setInterval(function () {
           initMap();
        }, 20000);

  function initMap() {
          // markers =[];
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng( 
21.4359571, 	
39.9866326),
          zoom:10
        });

       
           var text = new XMLHttpRequest();
          text.open("GET", "../../api/?service_code=2", true);
          text.onreadystatechange = function() {
        // Check states 4 = Ready to parse, 200 = found file
        if(text.readyState === 4 && text.status === 200) {
            var data = text.responseText;
            data_used = JSON.parse(data);
            // alert(data_used.data.length);
            var obj = data_used.data;
            for(var i=0;i< obj.length ;i++){  
           {
        
               
              markers.push( new google.maps.LatLng(obj[i].lat, obj[i].lang));

            	               var contentString =
              '<pre id="test' +markers.length+'" name="test"> ' +'National ID :'+obj[i].national_id +'<br>'+
              'Name :'+obj[i].name ;
         contentString +='</pre> ';
           
      

         var marker = new google.maps.Marker({
          position: markers[i],
          map: map,
          title: 'Uluru'
        });
        
       
      marker['infowindow'] = new google.maps.InfoWindow({
            content:contentString 
        });

    google.maps.event.addListener(marker, 'click', function() {
        this['infowindow'].open(map, this);
    });

          
           }
              // alert(markers.length);
            } //end for loop.
        } // end if function.

}
    text.send(null);
    // 
markers =[];
        } // end initMap.

      function initMap_old() {
        open_path_message();
         var locations = [
      ['Bondi Beach', 21.4359571, 39.9866326, 4],
      ['Coogee Beach',21.4359571 , 39.789455, 5],
      ['Cronulla Beach', 21.45625, 39.804568, 3],
      ['Manly Beach', 21.7846525, 39.7894556, 2],
      ['Maroubra Beach', 21.7951554, 39.15545, 1]
               ];

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 10,
          center: new google.maps.LatLng(21.4359571, 39.9866326),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i)); // end listener.
          
          } // end for loop.
      } // end init map function. 
        function initMap_create_path() {
        open_path_message();
         // reset.
          markers = [];
         counter = 0;
         infowindows = [];
            var uluru = {lat: 21.4359571, lng: 39.9866326};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: new google.maps.LatLng(21.4359571, 39.9866326)
        });


           map.addListener('click', function(event) {
          // addMarker(event.latLng);

                  var contentString =
         '<button id="' +markers.length+'" name="test" ';
         contentString +=' onclick="delete_marker(this.id);">Delete</button>';
          var infowindow = new google.maps.InfoWindow({
          content: contentString
        });
        // open_path_message();

        var marker = new google.maps.Marker({
          position: event.latLng,
          map: map,
          title: 'Uluru (Ayers Rock)'
        });
        markers.push(marker);
        open_path_message();
        counter++; 
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
        });
      }
      
      function delete_marker( counter){
        // alert("Delete Fuction" + counter);
       markers[counter].setMap(null) ;
       markers[counter].position=null;
        // alert("new length" +markers.length);
        
        open_path_message();
        show_points();

      }
      function show_points(){
        for(var i =0; i<markers.length;i++){
                   var contentString =
         '<button id="' +i+'" name="test" ';
         contentString +=' onclick="delete_marker(this.id);">Delete</button>';
          var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

        var marker = new google.maps.Marker({
          position: markers[i],
          map: map,
          title: 'Uluru'
        });
        
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
       

        }

      } // end init map function.



function open_path_message(){
  // alert(latlng);
  var string = "Please Select Points to draw route";
  for(var i=0;i<markers.length;i++){
    if(markers[i].position==null)continue;
    string +="<br >"+ markers[i].position;
  }
   document.getElementById("path").innerHTML = string;
  
  
}

function open_path_link(){
  var path = document.getElementById("path2");
  path.innerHTML ="Please Select buses and add them to route ";
  
}

// Accordion Javascript
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}